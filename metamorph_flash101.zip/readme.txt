1. Our free flash templates are desributed under a Creative Commons Attribution 2.5 License. We request you retain the link to www.metamorphozis.com in the footer. Other then that, have hun with the template: any changes, free destribution, etc. are welcomed.

2. Our paid flash templates can be edit with Flash MX 2004 or higher.

3. You may purchase source fla file of this easy free flash template. The price is $35.00. Please contact us here for details:
http://www.metamorphozis.com/contact/contact.php

Instructions How to Edit Easy Free Flash Template:

1.unzip the files. 
2.Locate folder named html. 
3.Inside that folder find the file named text.html.
4.Open this file with notepad. 
5.Change text to the one you need. 
6.Save the file. Open index.html to preview changed version.


Instructions How to Set Up the Contact Form

1.Inside the html folder find file named mail.php. 
2.Open it with notepad. 
3.Find the following code: $ToEmail = "support@metamorphozis.com";
4.Change support@metamorphozis.com to your email address. 
5.Upload html folder to your server and test the mail form.
6. Make sure your server supports php. List of recommended hosting providers with php support may be found here:
http://www.metamorphozis.com/website_hosting/index.php

Instructions how to set up special characters/other languages support:
please open text.html in notepad. Press File - Save as...select UTF-8 encoding and overwrite the old file. After that you should be able to use special characters.



